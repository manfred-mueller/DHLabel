﻿using AutoUpdaterDotNET;
using Microsoft.Win32;
using PdfSharp.Drawing;
using System;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace DHLabel
{
    public partial class Form1 : Form
    {
        private PdfLabelService _pdfService = new PdfLabelService();
        private Bitmap _currentLabel;
        private string _currentOriginalPdf;
        public bool endless = Properties.Settings.Default.endless;

        RegistryKey progKey =
            Registry.CurrentUser.OpenSubKey("Software\\Classes\\" + Application.ProductName, true);

        protected StatusBar mainStatusBar = new StatusBar();
        protected StatusBarPanel statusPanel = new StatusBarPanel();

        public Form1(string[] args)
        {
            InitializeComponent();

            CreateStatusBar();
            checkKey();

            cbOntop.Checked = Properties.Settings.Default.onTop;
            cbOpenWith.Checked = Properties.Settings.Default.openWith;
            cbEndless.Checked = endless;

            setTitle();
        }

        // ==========================================================
        // DATEI LADEN
        // ==========================================================

        public void LoadFile(string file)
        {
            try
            {
                _currentOriginalPdf = file;

                picboxLabel.Image?.Dispose();
                _currentLabel = _pdfService.RenderPdf(file, 203); // Preview
                picboxLabel.Image = _currentLabel;

                statusPanel.Text = file;
                enableControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Properties.Resources.ErrorLoadingPDFN + ex.Message);
            }
        }

        private void openPDF_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                LoadFile(openFileDialog1.FileName);
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            LoadFile(files[0]);
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effect = DragDropEffects.Copy;
        }

        // ==========================================================
        // DRUCK
        // ==========================================================

        private void printLabel_Click(object sender, EventArgs e)
        {
            PrintLabel();
        }

        private void PrintLabel()
        {
            if (string.IsNullOrEmpty(_currentOriginalPdf))
            {
                MessageBox.Show(Properties.Resources.NoPrintableLabelFound);
                return;
            }

            try
            {
                string printerName = Properties.Settings.Default.printOn;

                if (string.IsNullOrWhiteSpace(printerName))
                {
                    MessageBox.Show(Properties.Resources.NoPrinterConfigured);
                    return;
                }

                printDocument1.PrinterSettings.PrinterName = printerName;

                if (!printDocument1.PrinterSettings.IsValid)
                {
                    MessageBox.Show(Properties.Resources.PrinterNotAvailable);
                    return;
                }

                if (endless)
                {
                    printDocument1.DefaultPageSettings.PaperSize =
                        new PaperSize("Label100x150",
                            (int)(100 / 25.4 * 100),
                            (int)(150 / 25.4 * 100));

                    printDocument1.DefaultPageSettings.Margins =
                        new Margins(0, 0, 0, 0);
                }
                else
                {
                    printDocument1.DefaultPageSettings.PaperSize =
                        new PaperSize("A6", 413, 583);
                }

                printDocument1.DefaultPageSettings.Landscape = false;
                printDocument1.PrintController = new StandardPrintController();

                printDocument1.PrintPage -= PrintPageHandler;
                printDocument1.PrintPage += PrintPageHandler;

                printDocument1.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Properties.Resources.PrintingErrorN + ex.Message);
            }
        }

        private void PrintPageHandler(object sender, PrintPageEventArgs e)
        {
            float dpi = e.Graphics.DpiX;
            int targetDpi = (dpi < 250) ? 203 : 300;

            using (var img = _pdfService.RenderPdf(_currentOriginalPdf, targetDpi))
            {
                e.Graphics.TranslateTransform(
                    -e.PageSettings.HardMarginX,
                    -e.PageSettings.HardMarginY);

                float offsetX = 0;

                if (endless)
                {
                    float diffMm = 5.0f;
                    offsetX = (diffMm / 2f) / 25.4f * dpi;
                }
                else
                {
                    float diffMm = 3.0f;
                    offsetX = (diffMm / 2f) / 25.4f * dpi;
                }

                e.Graphics.DrawImage(img, offsetX, 0);
            }

            e.HasMorePages = false;
        }

        private void setPrinter_Click(object sender, EventArgs e)
        {
            PrintDialog dlg = new PrintDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                Properties.Settings.Default.printOn = dlg.PrinterSettings.PrinterName;
                Properties.Settings.Default.Save();
                setTitle();
            }
        }

        private void saveLabel_Click(object sender, EventArgs e)
        {
            if (_currentLabel == null)
            {
                MessageBox.Show(Properties.Resources.NoLabelLoaded);
                return;
            }

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                SaveCurrentLabel(saveFileDialog1.FileName);
        }

        // ==========================================================
        // EINSTELLUNGEN
        // ==========================================================

        private void cbEndless_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.endless = cbEndless.Checked;
            Properties.Settings.Default.Save();
        }

        private void cbOntop_CheckedChanged(object sender, EventArgs e)
        {
            TopMost = cbOntop.Checked;
            Properties.Settings.Default.onTop = cbOntop.Checked;
            Properties.Settings.Default.Save();
        }

        private void cbOpenWith_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.openWith = cbOpenWith.Checked;
            Properties.Settings.Default.Save();
        }

        // ==========================================================
        // ABOUT / UPDATE / QUIT
        // ==========================================================

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AboutBox1().ShowDialog();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                string url = "https://github.com/manfred-mueller/DHLabel/raw/master/version.xml";
                AutoUpdater.Start(url);
            }
            catch (Exception ex)
            {
                MessageBox.Show(Properties.Resources.UpdateErrorN + ex.Message);
            }
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // ==========================================================
        // UI HILFSFUNKTIONEN
        // ==========================================================

        private void enableControls()
        {
            btnPrint.Enabled = true;
            btnSavePDF.Enabled = true;
            savePDFToolStripMenuItem.Enabled = true;
            printToolStripMenuItem.Enabled = true;
        }

        private void CreateStatusBar()
        {
            statusPanel.BorderStyle = StatusBarPanelBorderStyle.Sunken;
            statusPanel.AutoSize = StatusBarPanelAutoSize.Spring;
            mainStatusBar.Panels.Add(statusPanel);
            mainStatusBar.ShowPanels = true;
            Controls.Add(mainStatusBar);
        }

        private void checkKey()
        {
            cbOpenWith.Checked = (progKey != null);
        }

        public void setTitle()
        {
            if (!string.IsNullOrEmpty(Properties.Settings.Default.printOn))
                Text = Application.ProductName + " – " + Properties.Settings.Default.printOn;
            else
                Text = Application.ProductName;
        }
        private void SaveCurrentLabel(string filename)
        {
            if (_currentOriginalPdf == null)
            {
                MessageBox.Show(Properties.Resources.NoLabelLoaded);
                return;
            }

            try
            {
                // Wir rendern neu mit 300 dpi für saubere PDF-Ausgabe
                using (var img = _pdfService.RenderPdf(_currentOriginalPdf, 300))
                {
                    PdfSharp.Pdf.PdfDocument doc = new PdfSharp.Pdf.PdfDocument();
                    PdfSharp.Pdf.PdfPage page = doc.AddPage();

                    // A6 = 105 x 148 mm
                    page.Width = XUnit.FromMillimeter(105);
                    page.Height = XUnit.FromMillimeter(148);

                    using (XGraphics gfx = XGraphics.FromPdfPage(page))
                    {
                        // 100 mm Label → mittig auf 105 mm
                        double offsetXmm = (105.0 - 100.0) / 2.0;

                        // temporär speichern (PdfSharp braucht Datei)
                        string tempPath = Path.GetTempFileName() + ".png";
                        img.Save(tempPath, System.Drawing.Imaging.ImageFormat.Png);

                        using (XImage xImg = XImage.FromFile(tempPath))
                        {
                            gfx.DrawImage(
                                xImg,
                                XUnit.FromMillimeter(offsetXmm),
                                0,
                                XUnit.FromMillimeter(100),
                                XUnit.FromMillimeter(148));
                        }

                        File.Delete(tempPath);
                    }

                    doc.Save(filename);
                    doc.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Properties.Resources.ErrorWhileSavingN + ex.Message);
            }
        }
    }
}