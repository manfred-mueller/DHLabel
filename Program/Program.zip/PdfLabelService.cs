﻿using PDFiumSharp;
using PDFiumSharp.Enums;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;

public class PdfLabelService
{
    public bool endless = DHLabel.Properties.Settings.Default.endless;
    public int targetHeightPx;
    public Bitmap RenderPdf(string pdfPath, int dpi, float scale = 1.0f)
    {
        using (var document = new PdfDocument(pdfPath))
        {
            var page = document.Pages[0];

            int fullWidthPx = (int)Math.Round(page.Size.Width / 72.0 * dpi);
            int fullHeightPx = (int)Math.Round(page.Size.Height / 72.0 * dpi);

            using (var pdfBitmap = new PDFiumBitmap(fullWidthPx, fullHeightPx, true))
            {
                pdfBitmap.FillRectangle(0, 0, fullWidthPx, fullHeightPx, 0xFFFFFFFF);

                page.Render(pdfBitmap,
                            PageOrientations.Normal,
                            RenderingFlags.Annotations);

                using (var stream = pdfBitmap.AsBmpStream())
                using (var fullImage = new Bitmap(stream))
                {
                    fullImage.SetResolution(dpi, dpi);

                    // --------------------------------------------------
                    // 1) Ausschnitt: vertikal 23-125 mm, horizontal 4-202 mm (deine aktuelle Variante)
                    // --------------------------------------------------
                    int xStartPx = (int)Math.Round(4.0 / 25.4 * dpi);
                    int yStartPx = (int)Math.Round(23.0 / 25.4 * dpi);
                    int cropWidthPx = (int)Math.Round((208.0 - 4.0) / 25.4 * dpi);   // 198 mm
                    int cropHeightPx = (int)Math.Round((125.0 - 23.0) / 25.4 * dpi);  // 102 mm

                    Rectangle cropRect = new Rectangle(xStartPx, yStartPx, cropWidthPx, cropHeightPx);

                    using (var cropped = fullImage.Clone(cropRect, fullImage.PixelFormat))
                    {
                        // --------------------------------------------------
                        // 2) 90° im Uhrzeigersinn drehen → Höhe wird Breite, Breite wird Höhe
                        // --------------------------------------------------
                        cropped.RotateFlip(RotateFlipType.Rotate90FlipNone);

                        // --------------------------------------------------
                        // 3) Zwei vertikale Bereiche entfernen → Bitmap wird kürzer
                        //    Entfernen: 80–90 mm und 100–125 mm (nach Drehung)
                        // --------------------------------------------------
                        int cutA_start = (int)Math.Round(55.0 / 25.4 * dpi);
                        int cutA_end = (int)Math.Round(60.0 / 25.4 * dpi);
                        int cutB_start = (int)Math.Round(90.0 / 25.4 * dpi);
                        int cutB_end = (int)Math.Round(120.0 / 25.4 * dpi);

                        int h1 = cutA_start;                           // 0 – 80 mm
                        int h2 = cutB_start - cutA_end;                // 90 – 100 mm
                        int h3 = cropped.Height - cutB_end;            // 125 – Ende

                        int newHeightPx = h1 + h2 + h3;

                        Bitmap combined = new Bitmap(cropped.Width, newHeightPx);
                        combined.SetResolution(dpi, dpi);

                        using (Graphics g = Graphics.FromImage(combined))
                        {
                            g.Clear(Color.White);
                            int destY = 0;

                            // Block 1: 0–80 mm
                            if (h1 > 0)
                            {
                                g.DrawImage(cropped,
                                    new Rectangle(0, destY, cropped.Width, h1),
                                    new Rectangle(0, 0, cropped.Width, h1),
                                    GraphicsUnit.Pixel);
                                destY += h1;
                            }

                            // Block 2: 90–100 mm
                            if (h2 > 0)
                            {
                                g.DrawImage(cropped,
                                    new Rectangle(0, destY, cropped.Width, h2),
                                    new Rectangle(0, cutA_end, cropped.Width, h2),
                                    GraphicsUnit.Pixel);
                                destY += h2;
                            }

                            // Block 3: 125 mm bis Ende
                            if (h3 > 0)
                            {
                                g.DrawImage(cropped,
                                    new Rectangle(0, destY, cropped.Width, h3),
                                    new Rectangle(0, cutB_end, cropped.Width, h3),
                                    GraphicsUnit.Pixel);
                                // destY += h3;  // nicht mehr nötig
                            }
                        }

                        // --------------------------------------------------
                        // 4) Proportional skalieren → Zielhöhe 150 mm * scale
                        // --------------------------------------------------
                        if (endless)
                        {
                            targetHeightPx = (int)Math.Round(158.0 / 25.4 * dpi * scale);
                        }
                        else
                        {
                            targetHeightPx = (int)Math.Round(148.0 / 25.4 * dpi * scale);
                        }

                        double aspectRatio = (double)combined.Width / combined.Height;
                        int targetWidthPx = (int)Math.Round(targetHeightPx * aspectRatio);

                        Bitmap final = new Bitmap(targetWidthPx, targetHeightPx);
                        final.SetResolution(dpi, dpi);

                        using (Graphics g = Graphics.FromImage(final))
                        {
                            g.Clear(Color.White);
                            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                            g.DrawImage(combined,
                                new Rectangle(0, 0, targetWidthPx, targetHeightPx));
                        }

                        return final;
                    }
                }
            }
        }
    }
}